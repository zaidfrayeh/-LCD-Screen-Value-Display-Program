

#include <stdint.h>
#include "LCD.h"
#include "Timer32.h"
#include "msp.h"

void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void);  // Enable interrupts
long StartCritical (void);    // previous I bit, disable interrupts
void EndCritical(long sr);    // restore I bit to previous value
void WaitForInterrupt(void);  // low power mode

// Macros
#define BusFreq 48					// assuming a 48 MHz system clock
#define T6us 6*BusFreq				// 6us
#define T40us 40*BusFreq			// 40us
#define T160us 160*BusFreq			// 160us
#define T1ms 1000*BusFreq			// 1ms
#define T1600us 1600*BusFreq		// 1.60ms
#define T5ms 5000*BusFreq			// 5ms
#define T15ms 15000*BusFreq			// 15ms

// Global Vars
uint8_t LCD_RS, LCD_E;				// LCD Enable and Register Select

/**************** Private Functions ****************/

void OutPort6() {
	P6OUT = (LCD_RS<<4) | (LCD_E<<5);
}

void SendPulse() {
	OutPort6();
	Timer32_Wait(T6us);				// wait 6us
	LCD_E = 1;						// E=1, R/W=0, RS=1
	OutPort6();
	Timer32_Wait(T6us);				// wait 6us
	LCD_E = 0;						// E=0, R/W=0, RS=1
	OutPort6();
}

void SendChar() {
	LCD_E = 0;
	LCD_RS = 1;						// E=0, R/W=0, RS=1
	SendPulse();
	Timer32_Wait(T1600us);			// wait 1.6ms
}

void SendCmd() {
	LCD_E = 0;
	LCD_RS = 0;						// E=0, R/W=0, RS=0
	SendPulse();
	Timer32_Wait(T40us);			// wait 40us
}

/**************** Public Functions ****************/
// Clear the LCD
// Inputs: none
// Outputs: none
void LCD_Clear() {
	LCD_OutCmd(0x01);				// Clear Display
	LCD_OutCmd(0x80);				// Move cursor back to 1st position
}

// Initialize LCD
// Inputs: none
// Outputs: none
void LCD_Init() {
	P4SEL0 &= ~0xF0;
	P4SEL1 &= ~0xF0;				// configure upper nibble of P4 as GPIO
	P4DIR |= 0xF0; 					// make upper nibble of P4 out

	P6SEL0 &= ~0x30;
	P6SEL1 &= ~0x30;				// configure P6.4 and P6.5 as GPIO
	P6DIR |= 0x30;					// make P6.4 and P6.5 out

	LCD_E = 0;
	LCD_RS = 0;						// E=0, R/W=0, RS=0
	OutPort6();

	LCD_OutCmd(0x30);				// command 0x30 = Wake up
	Timer32_Wait(T5ms);				// must wait 5ms, busy flag not available
	LCD_OutCmd(0x30);				// command 0x30 = Wake up #2
	Timer32_Wait(T160us);			// must wait 160us, busy flag not available
	LCD_OutCmd(0x30);				// command 0x30 = Wake up #3
	Timer32_Wait(T160us);			// must wait 160us, busy flag not available

	LCD_OutCmd(0x28);				// Function set: 4-bit/2-line
	LCD_Clear();
	LCD_OutCmd(0x10);				// Set cursor
	LCD_OutCmd(0x06);				// Entry mode set
}

// Output a character to the LCD
// Inputs: letter is ASCII character, 0 to 0x7F
// Outputs: none
void LCD_OutChar(char letter) {
	unsigned char let_low = (0x0F&letter)<<4;
	unsigned char let_high = 0xF0&letter;
    long intstatus = StartCritical();

	P4OUT = let_high;
	SendChar();
	P4OUT = let_low;
	SendChar();
	EndCritical( intstatus );
	Timer32_Wait(T1ms);				// wait 1ms
}

// Output a command to the LCD
// Inputs: 8-bit command
// Outputs: none
void LCD_OutCmd(unsigned char command) {
	unsigned char com_low = (0x0F&command)<<4;
	unsigned char com_high = 0xF0&command;
    long intstatus = StartCritical();

	P4OUT = com_high;
	SendCmd();
	P4OUT = com_low;
	SendCmd();
	EndCritical( intstatus );
	Timer32_Wait(T1ms);				// wait 1ms
}

//------------LCD_OutString------------
// Output String (NULL termination)
// Input: pointer to a NULL-terminated string to be transferred
// Output: none
void LCD_OutString(char *ptr) {

    int x;
    for(x = 0 ; x<=18 ; x++)
    {
        if(ptr[x] == 0){
            return 0;
                        }

        LCD_OutChar(ptr[x]);
    }

                                }

//-----------------------LCD_OutUDec-----------------------
// Output a 32-bit number in unsigned decimal format
// Input: 32-bit number to be transferred
// Output: none
// Variable format 1-10 digits with no space before or after
void LCD_OutUDec(uint32_t n) {
// This function uses recursion to convert decimal number
//   of unspecified length as an ASCII string
    static char s[16];

        static int32_t i;

        static uint32_t count ;


           if(n/10){
               count++;
               LCD_OutUDec(n/10);

           }


           s[i++] = abs(n) % 10 + '0';

           s[i] = '\0';


           if(count == i - 1){

           LCD_OutString(s);
           i = 0;
           count = 0;
           }




    }

void hextodec(uint32_t hexa) {

     if(hexa == 0 ) LCD_OutChar(0x30);
     else if(hexa == 1 )LCD_OutChar(0x31);
     else if(hexa == 2 )LCD_OutChar(0x32);
     else if(hexa == 3 )LCD_OutChar(0x33);
     else if(hexa == 4 )LCD_OutChar(0x34);
     else if(hexa == 5 )LCD_OutChar(0x35);
     else if(hexa == 6 )LCD_OutChar(0x36);
     else if(hexa == 7 )LCD_OutChar(0x37);
     else if(hexa == 8 )LCD_OutChar(0x38);
     else if(hexa == 9 )LCD_OutChar(0x39);



}


// -----------------------LCD_OutUFix----------------------
// Output characters to LCD display in fixed-point format
// unsigned decimal, resolution 0.001, range 0.000 to 9.999
// Inputs:  an unsigned 32-bit number
// Outputs: none
// E.g., 0,    then output "0.000 "
//       3,    then output "0.003 "
//       89,   then output "0.089 "
//       123,  then output "0.123 "
//       9999, then output "9.999 "
//       9999, then output "*.*** "
void LCD_OutUFix(uint32_t num) {

           static char array[16];
           static int32_t i;
           static uint32_t count ;

           if(count == 0)
        {
           if(num < 10){

               array[i++] = '0';
               array[i++] = '.';
               array[i++] = '0';
               array[i++] = '0';

                       }
           if(num >= 10 && num < 99){
               array[i++] = '0';
               array[i++] = '.';
               array[i++] = '0';
                                    }
           if(num >= 100 && num < 999){
               array[i++] = '0';
               array[i++] = '.';
                                       }
      }


              if(num/10){
                  count++;
                  LCD_OutUFix(num/10);

                          }

              array[i++] = abs(num) % 10 + '0';

              if(count == 3){

                  if(i == 1){
                      array[i++] = '.';
                            }
                            }

              array[i] = '\0';

              if(num < 10){

                  if(count == i - 5){

                            LCD_OutString(array);
                            i = 0;
                            count = 0;
                                    }

                          }
              if(num >= 10 && num < 99){
                  if(count == i - 4){

                            LCD_OutString(array);
                            i = 0;
                            count = 0;
                                    }
                                       }
              if(num >= 100 && num < 999){
                  if(count == i - 3){

                            LCD_OutString(array);
                            i = 0;
                            count = 0;
                                     }
                                         }

              if(num >= 1000){

                  if(count + 2 == i){

                      LCD_OutString(array);
                      i = 0;
                      count = 0;
                              }
                              }


            }


