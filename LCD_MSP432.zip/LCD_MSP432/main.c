#include <stdint.h>
#include "LCD.h"
#include "Timer32.h"
#include "ADC14.h"
#include "SysTickInts.h"

void main()
{
    LCD_Init();

    ADC0_InitSWTriggerCh0();

    SysTick_Init(2344);
    LCD_OutString("ZAID LAB 5");
    while(1){

        if(mailbox == 1){

    uint32_t ADC = SysTick_Mailbox();

    ADC = ADC * 0.12208;

    LCD_OutCmd(0xC0);
    LCD_OutUFix(ADC);
    LCD_OutString(" CM");
    mailbox = 0;

        }
        Timer32_Wait10ms(30);

    }

}
