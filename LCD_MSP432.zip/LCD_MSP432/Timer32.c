// Timer32.c
// Runs on MSP432

// Adapted from SysTick.c from the book:
/* "Embedded Systems: Introduction to MSP432 Microcontrollers",
   ISBN: 978-1469998749, Jonathan Valvano, copyright (c) 2015
   Volume 1, Program 4.7
*/

#include <stdint.h>
#include "msp432p401r.h"

// Time delay using busy wait
// The delay parameter is in units of the core clock (units of 333 nsec for 3 MHz clock)
void Timer32_Wait( uint32_t delay ){

  if(delay <= 1){ return; } // Immediately return if requested delay less than one clock

  TIMER32_1->CONTROL = (TIMER32_1->CONTROL & ~(0x000000EF)) | 0x000000C3;
    // Timer32 in periodic mode, no interrupts, no prescale, 32-bit, and one-shot
  TIMER32_1->LOAD = delay - 1; // Will count down to 0
  while( TIMER32_1->VALUE ){} // Wait until timer expires (value equals 0)
  // Or, clear interrupt and wait for raw interrupt flag to be set
  //TIMER32_1->INTCLR = 0;
  //while( !(TIMER32_1->RIS & 0x1) ){}
  return;
}

// Time delay using busy wait
// This assumes 3 MHz system clock
void Timer32_Wait10ms( uint32_t delay ){
  uint32_t i;
  for( i = 0; i < delay; i++ ){
    Timer32_Wait(30000);  // wait 10ms (assumes 3 MHz clock)
  }
  return;
}
