// Timer32.h
// Runs on MSP432

// Adapted from SysTick.h from the book:
/* "Embedded Systems: Introduction to MSP432 Microcontrollers",
   ISBN: 978-1469998749, Jonathan Valvano, copyright (c) 2015
   Volume 1, Program 4.7
*/

#ifndef __TIMER32_H__
#define __TIMER32_H__

// Time delay using busy wait
// The delay parameter is in units of the core clock (units of 333 nsec for 3 MHz clock)
void Timer32_Wait( uint32_t delay );

// Time delay using busy wait
// This assumes 3 MHz system clock
void Timer32_Wait10ms( uint32_t delay );

#endif
